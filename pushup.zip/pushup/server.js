// server.js
const express = require('express');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const WebSocket = require('ws');
const http = require('http');

const SERIAL_PORT = "COM8";   // <-- set your COM port here
const BAUD = 115200;          // <-- set baud rate here

const app = express();
app.use(express.static('public'));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Broadcast helper
function broadcast(obj) {
  const s = JSON.stringify(obj);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) client.send(s);
  });
}

// Basic connection log
wss.on('connection', ws => {
  console.log('WS client connected');
  ws.send(JSON.stringify({ msg: 'welcome', ts: Date.now() }));
});

// Open serial port
let serialConnected = false;
const port = new SerialPort({ path: SERIAL_PORT, baudRate: BAUD }, (err) => {
  if (err) {
    console.error('Error opening serial port:', err.message);
    console.log('Starting in simulation mode...');
    startSimulation();
    // process.exit(1); // Don't exit on dev environment
  } else {
    serialConnected = true;
    console.log(`Serial ${SERIAL_PORT} opened at ${BAUD}`);
    const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));
    
    // Tolerant parsing: accept full JSON line or extract JSON substring from a mixed line
    parser.on('data', line => {
      processLine(line);
    });
  }
});

function processLine(line) {
  line = line.trim();
  let payload = null;

  // Try to parse the whole line as JSON
  try {
    payload = JSON.parse(line);
  } catch (e) {
    // Try to extract the first JSON object in the line (from '{' to last '}')
    const first = line.indexOf('{');
    const last = line.lastIndexOf('}');
    if (first !== -1 && last !== -1 && last > first) {
      const jsonStr = line.slice(first, last + 1);
      try {
        payload = JSON.parse(jsonStr);
      } catch (err) {
        payload = null;
      }
    }
  }

  // If not parsed, treat as raw text
  if (!payload) {
    payload = { raw: line };
  }

  const message = { ts: Date.now(), data: payload };
  broadcast(message);
  console.log('→', JSON.stringify(message));
}

function startSimulation() {
  setInterval(() => {
    // Simulate some pushup data or random data
    // Assuming the app expects something like { count: 1 } or similar based on "pushup" name
    // But since we don't know the exact schema, let's send a generic object and a raw message
    const mockData = { 
      val: Math.floor(Math.random() * 100),
      simulated: true
    };
    // Also simulate the raw line processing
    processLine(JSON.stringify(mockData));
  }, 2000);
}

const HTTP_PORT = 3000;
server.listen(HTTP_PORT, () => {
  console.log(`Server listening on http://localhost:${HTTP_PORT}`);
});
